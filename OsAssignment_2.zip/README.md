# OsAssignment_repo2


Task 1

** Function: ** gCsn - Get current segment name ** Parameters: ** ssa - Segment start address ** sea - Segment end address ** csn - Current segement name ** Returns: ** sni - Segment name index

** Function: ** print_pmaps - Prints pmaps ** Parameters: ** ctx - Context ** Returns: ** sni - Segment name index

Task 2

** Function: ** print_page_table - Prints page table ** Parameters: ** ctx - Context ** adr - Address ** Returns: ** 0

Task 3

** Function: ** do_dfork - Prints page table ** Parameters: ** cha - Child stack address ** Returns: ** pid - Process id.
